export interface User {
  id: string;
  email: string;
  name: string;
  createdAt: string;
}

export interface MoodEntry {
  id: string;
  userId: string;
  date: string;
  mood: number; // 1-5 scale
  note?: string;
  activities?: string[];
}

export interface Article {
  id: string;
  title: string;
  category: string;
  excerpt: string;
  content: string;
  imageUrl: string;
  readTime: number;
  author: string;
  publishedAt: string;
}

export interface ForumPost {
  id: string;
  userId: string;
  userName: string;
  title: string;
  content: string;
  createdAt: string;
  replies: ForumReply[];
  likes: number;
  category: string;
}

export interface ForumReply {
  id: string;
  userId: string;
  userName: string;
  content: string;
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "bot";
  content: string;
  timestamp: string;
}
