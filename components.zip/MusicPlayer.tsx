import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router";
import { useLanguage } from "../contexts/LanguageContext";
import { Button } from "./ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Slider } from "./ui/slider";
import { Switch } from "./ui/switch";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Play, Pause, Volume2, VolumeX, Music2, LogOut, Globe } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

// Sample music tracks (using free music URLs for demonstration)
const musicTracks = [
  {
    id: 1,
    title: "Sample Track 1",
    artist: "Artist 1",
    url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
  },
  {
    id: 2,
    title: "Sample Track 2",
    artist: "Artist 2",
    url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
  },
  {
    id: 3,
    title: "Sample Track 3",
    artist: "Artist 3",
    url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
  },
];

export default function MusicPlayer() {
  const navigate = useNavigate();
  const { language, setLanguage, t } = useLanguage();
  const audioRef = useRef<HTMLAudioElement>(null);

  const [currentTrack, setCurrentTrack] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(50);
  const [autoplay, setAutoplay] = useState(false);
  const [loop, setLoop] = useState(false);
  const [muted, setMuted] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);

  useEffect(() => {
    // Check if user is logged in
    const user = localStorage.getItem("user");
    if (!user) {
      navigate("/");
    }
  }, [navigate]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const updateTime = () => setCurrentTime(audio.currentTime);
    const updateDuration = () => setDuration(audio.duration);
    const handleEnded = () => {
      if (loop) {
        audio.currentTime = 0;
        const playPromise = audio.play();
        if (playPromise !== undefined) {
          playPromise.catch((error) => {
            console.log("Loop playback prevented:", error);
            setIsPlaying(false);
          });
        }
      } else if (autoplay && currentTrack < musicTracks.length - 1) {
        setCurrentTrack((prev) => prev + 1);
      } else {
        setIsPlaying(false);
      }
    };

    audio.addEventListener("timeupdate", updateTime);
    audio.addEventListener("loadedmetadata", updateDuration);
    audio.addEventListener("ended", handleEnded);

    return () => {
      audio.removeEventListener("timeupdate", updateTime);
      audio.removeEventListener("loadedmetadata", updateDuration);
      audio.removeEventListener("ended", handleEnded);
    };
  }, [loop, autoplay, currentTrack]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume / 100;
    }
  }, [volume]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.muted = muted;
    }
  }, [muted]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.loop = loop;
    }
  }, [loop]);

  // Handle track changes and autoplay
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    // Reset current time when track changes
    setCurrentTime(0);
    audio.load();

    // If was playing before track change, play new track
    if (isPlaying && autoplay) {
      const playPromise = audio.play();
      if (playPromise !== undefined) {
        playPromise.catch((error) => {
          console.log("Autoplay prevented:", error);
          setIsPlaying(false);
        });
      }
    }
  }, [currentTrack]);

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
        setIsPlaying(false);
      } else {
        const playPromise = audioRef.current.play();
        if (playPromise !== undefined) {
          playPromise
            .then(() => {
              setIsPlaying(true);
            })
            .catch((error) => {
              console.log("Playback prevented:", error);
              setIsPlaying(false);
            });
        }
      }
    }
  };

  const handleVolumeChange = (values: number[]) => {
    setVolume(values[0]);
  };

  const handleSeek = (values: number[]) => {
    if (audioRef.current) {
      audioRef.current.currentTime = values[0];
      setCurrentTime(values[0]);
    }
  };

  const handleTrackChange = (trackIndex: string) => {
    const index = parseInt(trackIndex);
    setCurrentTrack(index);
    setIsPlaying(false);
    if (audioRef.current) {
      audioRef.current.pause();
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("user");
    navigate("/");
  };

  const formatTime = (time: number) => {
    if (isNaN(time)) return "0:00";
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, "0")}`;
  };

  const track = musicTracks[currentTrack];

  // Generate visualizer bars based on volume and playback
  const visualizerBars = Array.from({ length: 40 }, (_, i) => i);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 p-4 flex items-center justify-center relative overflow-hidden">
      {/* Animated background orbs */}
      <motion.div
        className="absolute top-10 left-10 size-72 bg-white/10 rounded-full blur-3xl"
        animate={{
          scale: [1, 1.2, 1],
          x: [0, 50, 0],
          y: [0, 30, 0],
        }}
        transition={{
          duration: 15,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      <motion.div
        className="absolute bottom-10 right-10 size-96 bg-pink-300/20 rounded-full blur-3xl"
        animate={{
          scale: [1, 1.3, 1],
          x: [0, -40, 0],
          y: [0, -50, 0],
        }}
        transition={{
          duration: 12,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-2xl relative z-10"
      >
        <Card className="backdrop-blur-sm bg-white/95 shadow-2xl">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <motion.div
                  animate={isPlaying ? {
                    rotate: [0, 360],
                  } : {}}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: "linear",
                  }}
                >
                  <Music2 className="size-8 text-purple-600" />
                </motion.div>
                <CardTitle className="text-2xl">{t("musicPlayer")}</CardTitle>
              </div>
              <div className="flex items-center gap-2">
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Select value={language} onValueChange={(val) => setLanguage(val as any)}>
                    <SelectTrigger className="w-[120px]">
                      <Globe className="size-4 mr-2" />
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="es">Español</SelectItem>
                      <SelectItem value="fr">Français</SelectItem>
                      <SelectItem value="de">Deutsch</SelectItem>
                      <SelectItem value="zh">中文</SelectItem>
                      <SelectItem value="ja">日本語</SelectItem>
                    </SelectContent>
                  </Select>
                </motion.div>
                <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
                  <Button variant="outline" size="icon" onClick={handleLogout}>
                    <LogOut className="size-4" />
                  </Button>
                </motion.div>
              </div>
            </div>
            <CardDescription>{t("nowPlaying")}: {track.title}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Track Info with Album Art */}
            <AnimatePresence mode="wait">
              <motion.div
                key={currentTrack}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
                className="bg-gradient-to-r from-purple-100 to-pink-100 dark:from-purple-900 dark:to-pink-900 p-8 rounded-lg text-center relative overflow-hidden"
              >
                {/* Animated background pattern */}
                <div className="absolute inset-0 opacity-10">
                  {visualizerBars.map((bar) => (
                    <motion.div
                      key={bar}
                      className="absolute bottom-0 bg-purple-600"
                      style={{
                        left: `${(bar / visualizerBars.length) * 100}%`,
                        width: `${100 / visualizerBars.length}%`,
                      }}
                      animate={isPlaying ? {
                        height: [
                          `${Math.random() * 50 + 10}%`,
                          `${Math.random() * 80 + 20}%`,
                          `${Math.random() * 50 + 10}%`,
                        ],
                      } : { height: "5%" }}
                      transition={{
                        duration: 0.5 + Math.random() * 0.5,
                        repeat: Infinity,
                        ease: "easeInOut",
                      }}
                    />
                  ))}
                </div>

                <motion.div
                  animate={isPlaying ? {
                    scale: [1, 1.05, 1],
                  } : {}}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                  className="relative z-10"
                >
                  <Music2 className="size-24 mx-auto mb-4 text-purple-600" />
                </motion.div>
                <motion.h2
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-2xl mb-2 relative z-10"
                >
                  {track.title}
                </motion.h2>
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.1 }}
                  className="text-muted-foreground relative z-10"
                >
                  {track.artist}
                </motion.p>
              </motion.div>
            </AnimatePresence>

            {/* Track Selection */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
              className="space-y-2"
            >
              <Label>Select Track</Label>
              <Select value={currentTrack.toString()} onValueChange={handleTrackChange}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {musicTracks.map((track, index) => (
                    <SelectItem key={track.id} value={index.toString()}>
                      {track.title} - {track.artist}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </motion.div>

            {/* Progress Bar */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="space-y-2"
            >
              <Slider
                value={[currentTime]}
                max={duration || 100}
                step={1}
                onValueChange={handleSeek}
              />
              <div className="flex justify-between text-sm text-muted-foreground">
                <motion.span
                  key={`current-${currentTime}`}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                >
                  {formatTime(currentTime)}
                </motion.span>
                <span>{formatTime(duration)}</span>
              </div>
            </motion.div>

            {/* Play/Pause Button */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3 }}
              className="flex justify-center"
            >
              <motion.div
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                <Button
                  size="lg"
                  onClick={togglePlay}
                  className="size-16 rounded-full relative overflow-hidden"
                >
                  <AnimatePresence mode="wait">
                    <motion.div
                      key={isPlaying ? "pause" : "play"}
                      initial={{ scale: 0, rotate: -180 }}
                      animate={{ scale: 1, rotate: 0 }}
                      exit={{ scale: 0, rotate: 180 }}
                      transition={{ duration: 0.3 }}
                    >
                      {isPlaying ? <Pause className="size-6" /> : <Play className="size-6 ml-1" />}
                    </motion.div>
                  </AnimatePresence>
                  
                  {/* Ripple effect when playing */}
                  {isPlaying && (
                    <motion.div
                      className="absolute inset-0 bg-white/30 rounded-full"
                      initial={{ scale: 1, opacity: 0.5 }}
                      animate={{ scale: 2, opacity: 0 }}
                      transition={{
                        duration: 1.5,
                        repeat: Infinity,
                        ease: "easeOut",
                      }}
                    />
                  )}
                </Button>
              </motion.div>
            </motion.div>

            {/* Volume Control */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
              className="space-y-2"
            >
              <div className="flex items-center justify-between">
                <Label className="flex items-center gap-2">
                  <motion.div
                    animate={!muted && isPlaying ? {
                      scale: [1, 1.2, 1],
                    } : {}}
                    transition={{
                      duration: 0.5,
                      repeat: Infinity,
                    }}
                  >
                    {muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
                  </motion.div>
                  {t("volume")}
                </Label>
                <motion.span
                  key={volume}
                  initial={{ scale: 1.2 }}
                  animate={{ scale: 1 }}
                  className="text-sm text-muted-foreground"
                >
                  {volume}%
                </motion.span>
              </div>
              <Slider
                value={[volume]}
                max={100}
                step={1}
                onValueChange={handleVolumeChange}
                disabled={muted}
              />
            </motion.div>

            {/* Controls */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                whileHover={{ scale: 1.02 }}
                className="flex items-center justify-between p-3 border rounded-lg"
              >
                <Label htmlFor="autoplay" className="cursor-pointer">
                  {t("autoplay")}
                </Label>
                <Switch
                  id="autoplay"
                  checked={autoplay}
                  onCheckedChange={setAutoplay}
                />
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                whileHover={{ scale: 1.02 }}
                className="flex items-center justify-between p-3 border rounded-lg"
              >
                <Label htmlFor="loop" className="cursor-pointer">
                  {t("loop")}
                </Label>
                <Switch
                  id="loop"
                  checked={loop}
                  onCheckedChange={setLoop}
                />
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.7 }}
                whileHover={{ scale: 1.02 }}
                className="flex items-center justify-between p-3 border rounded-lg"
              >
                <Label htmlFor="muted" className="cursor-pointer">
                  {t("muted")}
                </Label>
                <Switch
                  id="muted"
                  checked={muted}
                  onCheckedChange={setMuted}
                />
              </motion.div>
            </div>

            {/* Hidden Audio Element */}
            <audio ref={audioRef} src={track.url} />
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}