import { useEffect, useState } from "react";
import { Outlet, useNavigate, NavLink } from "react-router";
import { Button } from "../ui/button";
import { Heart, LayoutDashboard, Wind, BookOpen, MessageCircle, Phone, Users, LogOut, Menu, X } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function MHLayout() {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const currentUser = localStorage.getItem("mh_current_user");
    if (!currentUser) {
      navigate("/");
    } else {
      setUser(JSON.parse(currentUser));
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("mh_current_user");
    navigate("/");
  };

  const navItems = [
    { to: "/app/dashboard", icon: LayoutDashboard, label: "Dashboard" },
    { to: "/app/stress-relief", icon: Wind, label: "Stress Relief" },
    { to: "/app/articles", icon: BookOpen, label: "Articles" },
    { to: "/app/chatbot", icon: MessageCircle, label: "Chatbot" },
    { to: "/app/emergency", icon: Phone, label: "Emergency" },
    { to: "/app/forum", icon: Users, label: "Forum" },
  ];

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <Heart className="size-8 text-pink-500" fill="currentColor" />
              <span className="text-xl">MindfulCare</span>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-1">
              {navItems.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  className={({ isActive }) =>
                    `flex items-center gap-2 px-3 py-2 rounded-lg transition-colors ${
                      isActive
                        ? "bg-purple-100 text-purple-700"
                        : "text-gray-600 hover:bg-gray-100"
                    }`
                  }
                >
                  <item.icon className="size-4" />
                  <span className="text-sm">{item.label}</span>
                </NavLink>
              ))}
            </nav>

            <div className="flex items-center gap-4">
              <span className="hidden sm:inline text-sm text-gray-600">
                Hello, {user.name}
              </span>
              <Button variant="outline" size="sm" onClick={handleLogout} className="hidden md:flex">
                <LogOut className="size-4 mr-2" />
                Logout
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="md:hidden"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <X className="size-5" /> : <Menu className="size-5" />}
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="md:hidden border-t bg-white overflow-hidden"
            >
              <nav className="px-4 py-2 space-y-1">
                {navItems.map((item) => (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    onClick={() => setMobileMenuOpen(false)}
                    className={({ isActive }) =>
                      `flex items-center gap-2 px-3 py-2 rounded-lg transition-colors ${
                        isActive
                          ? "bg-purple-100 text-purple-700"
                          : "text-gray-600 hover:bg-gray-100"
                      }`
                    }
                  >
                    <item.icon className="size-4" />
                    <span className="text-sm">{item.label}</span>
                  </NavLink>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleLogout}
                  className="w-full mt-2"
                >
                  <LogOut className="size-4 mr-2" />
                  Logout
                </Button>
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Outlet />
      </main>
    </div>
  );
}
