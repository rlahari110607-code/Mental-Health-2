import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Wind, Brain, Heart, Play, Pause, RotateCcw } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

const breathingExercises = [
  {
    id: "478",
    name: "4-7-8 Breathing",
    description: "Inhale for 4, hold for 7, exhale for 8",
    steps: [
      { phase: "Inhale", duration: 4 },
      { phase: "Hold", duration: 7 },
      { phase: "Exhale", duration: 8 },
    ],
  },
  {
    id: "box",
    name: "Box Breathing",
    description: "Inhale, hold, exhale, hold - all for 4 counts",
    steps: [
      { phase: "Inhale", duration: 4 },
      { phase: "Hold", duration: 4 },
      { phase: "Exhale", duration: 4 },
      { phase: "Hold", duration: 4 },
    ],
  },
  {
    id: "calm",
    name: "Calming Breath",
    description: "Inhale for 4, exhale for 6",
    steps: [
      { phase: "Inhale", duration: 4 },
      { phase: "Exhale", duration: 6 },
    ],
  },
];

const meditationGuides = [
  {
    title: "Body Scan Meditation",
    duration: "10 minutes",
    description: "Systematically focus on different parts of your body, releasing tension and promoting relaxation.",
  },
  {
    title: "Mindful Breathing",
    duration: "5 minutes",
    description: "Focus your attention on your breath, observing each inhale and exhale without judgment.",
  },
  {
    title: "Loving-Kindness Meditation",
    duration: "15 minutes",
    description: "Cultivate feelings of compassion and love towards yourself and others.",
  },
  {
    title: "Visualization",
    duration: "8 minutes",
    description: "Create a peaceful mental image to promote calmness and reduce stress.",
  },
];

export default function MHStressRelief() {
  const [selectedExercise, setSelectedExercise] = useState(breathingExercises[0]);
  const [isActive, setIsActive] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [countdown, setCountdown] = useState(0);
  const [completedCycles, setCompletedCycles] = useState(0);

  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (isActive && countdown > 0) {
      interval = setInterval(() => {
        setCountdown((prev) => prev - 1);
      }, 1000);
    } else if (isActive && countdown === 0) {
      // Move to next step
      const nextStep = (currentStep + 1) % selectedExercise.steps.length;
      
      if (nextStep === 0) {
        setCompletedCycles((prev) => prev + 1);
      }

      setCurrentStep(nextStep);
      setCountdown(selectedExercise.steps[nextStep].duration);
    }

    return () => clearInterval(interval);
  }, [isActive, countdown, currentStep, selectedExercise]);

  const startExercise = () => {
    setIsActive(true);
    setCountdown(selectedExercise.steps[0].duration);
    setCurrentStep(0);
    setCompletedCycles(0);
  };

  const pauseExercise = () => {
    setIsActive(false);
  };

  const resetExercise = () => {
    setIsActive(false);
    setCountdown(0);
    setCurrentStep(0);
    setCompletedCycles(0);
  };

  const currentPhase = selectedExercise.steps[currentStep];
  const progress = currentPhase
    ? ((currentPhase.duration - countdown) / currentPhase.duration) * 100
    : 0;

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-3xl mb-2">Stress Relief Activities</h1>
        <p className="text-muted-foreground">
          Take a moment to relax and center yourself
        </p>
      </motion.div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Breathing Exercise */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="lg:col-span-2"
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Wind className="size-5 text-blue-500" />
                Breathing Exercises
              </CardTitle>
              <CardDescription>
                Guided breathing to reduce stress and anxiety
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Exercise Selection */}
              <div className="grid grid-cols-3 gap-2">
                {breathingExercises.map((exercise) => (
                  <Button
                    key={exercise.id}
                    variant={selectedExercise.id === exercise.id ? "default" : "outline"}
                    onClick={() => {
                      setSelectedExercise(exercise);
                      resetExercise();
                    }}
                    className="h-auto py-3 flex-col"
                  >
                    <div className="font-semibold text-sm">{exercise.name}</div>
                    <div className="text-xs opacity-80 mt-1">{exercise.description}</div>
                  </Button>
                ))}
              </div>

              {/* Breathing Animation */}
              <div className="flex flex-col items-center justify-center py-8">
                <div className="relative w-64 h-64 flex items-center justify-center">
                  {/* Animated Circle */}
                  <motion.div
                    className="absolute inset-0 rounded-full bg-gradient-to-br from-blue-400 to-purple-500"
                    animate={{
                      scale: isActive ? (currentPhase?.phase === "Inhale" ? 1.2 : currentPhase?.phase === "Exhale" ? 0.8 : 1) : 1,
                      opacity: isActive ? [0.6, 1, 0.6] : 0.6,
                    }}
                    transition={{
                      duration: currentPhase?.duration || 4,
                      ease: "easeInOut",
                    }}
                  />

                  {/* Text Content */}
                  <div className="relative z-10 text-center text-white">
                    <AnimatePresence mode="wait">
                      {isActive ? (
                        <motion.div
                          key={currentStep}
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.8 }}
                          className="space-y-2"
                        >
                          <div className="text-2xl font-bold">{currentPhase?.phase}</div>
                          <div className="text-6xl font-bold">{countdown}</div>
                          <div className="text-sm opacity-90">
                            Cycle {completedCycles + 1}
                          </div>
                        </motion.div>
                      ) : (
                        <motion.div
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                        >
                          <Wind className="size-16 mx-auto mb-2" />
                          <div className="text-lg">Ready to breathe</div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
              </div>

              {/* Controls */}
              <div className="flex items-center justify-center gap-4">
                {!isActive ? (
                  <Button onClick={startExercise} size="lg" className="gap-2">
                    <Play className="size-5" />
                    Start
                  </Button>
                ) : (
                  <Button onClick={pauseExercise} size="lg" variant="secondary" className="gap-2">
                    <Pause className="size-5" />
                    Pause
                  </Button>
                )}
                <Button onClick={resetExercise} size="lg" variant="outline" className="gap-2">
                  <RotateCcw className="size-5" />
                  Reset
                </Button>
              </div>

              {isActive && (
                <div className="space-y-2">
                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <motion.div
                      className="h-full bg-gradient-to-r from-blue-500 to-purple-500"
                      initial={{ width: 0 }}
                      animate={{ width: `${progress}%` }}
                      transition={{ duration: 0.3 }}
                    />
                  </div>
                  <p className="text-sm text-center text-muted-foreground">
                    Completed {completedCycles} cycle{completedCycles !== 1 ? 's' : ''}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Meditation Guides */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="size-5 text-purple-500" />
                Meditation Guides
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {meditationGuides.map((guide, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 + index * 0.1 }}
                  className="p-4 rounded-lg border hover:border-purple-300 hover:bg-purple-50/50 transition-all cursor-pointer"
                >
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-semibold">{guide.title}</h3>
                    <span className="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded">
                      {guide.duration}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground">{guide.description}</p>
                </motion.div>
              ))}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Quick Tips */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Heart className="size-5 text-pink-500" />
              Quick Stress Relief Tips
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-4">
              {[
                "Take a 5-minute walk outside",
                "Practice progressive muscle relaxation",
                "Listen to calming music",
                "Write in a journal",
                "Connect with a friend",
                "Practice gratitude",
              ].map((tip, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.5 + index * 0.05 }}
                  className="p-4 rounded-lg bg-gradient-to-br from-blue-50 to-purple-50 text-center"
                >
                  <p className="text-sm">{tip}</p>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
