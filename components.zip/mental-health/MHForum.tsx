import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Textarea } from "../ui/textarea";
import { Label } from "../ui/label";
import { Badge } from "../ui/badge";
import { Users, MessageCircle, Heart, Plus, Send, Clock } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { ForumPost, ForumReply } from "../../types/mental-health";
import { forumPosts as initialPosts } from "../../data/mental-health-data";

export default function MHForum() {
  const [user, setUser] = useState<any>(null);
  const [posts, setPosts] = useState<ForumPost[]>(initialPosts);
  const [selectedPost, setSelectedPost] = useState<ForumPost | null>(null);
  const [showNewPost, setShowNewPost] = useState(false);
  const [newPostData, setNewPostData] = useState({
    title: "",
    content: "",
    category: "Support",
  });
  const [replyContent, setReplyContent] = useState("");

  useEffect(() => {
    const currentUser = JSON.parse(localStorage.getItem("mh_current_user") || "{}");
    setUser(currentUser);

    // Load posts from localStorage
    const savedPosts = localStorage.getItem("mh_forum_posts");
    if (savedPosts) {
      setPosts(JSON.parse(savedPosts));
    }
  }, []);

  const savePosts = (updatedPosts: ForumPost[]) => {
    setPosts(updatedPosts);
    localStorage.setItem("mh_forum_posts", JSON.stringify(updatedPosts));
  };

  const createPost = () => {
    if (!newPostData.title.trim() || !newPostData.content.trim()) return;

    const newPost: ForumPost = {
      id: Date.now().toString(),
      userId: user.id,
      userName: "Anonymous User",
      title: newPostData.title,
      content: newPostData.content,
      category: newPostData.category,
      createdAt: new Date().toISOString(),
      replies: [],
      likes: 0,
    };

    savePosts([newPost, ...posts]);
    setNewPostData({ title: "", content: "", category: "Support" });
    setShowNewPost(false);
  };

  const addReply = () => {
    if (!selectedPost || !replyContent.trim()) return;

    const newReply: ForumReply = {
      id: Date.now().toString(),
      userId: user.id,
      userName: "Anonymous User",
      content: replyContent,
      createdAt: new Date().toISOString(),
    };

    const updatedPosts = posts.map((post) =>
      post.id === selectedPost.id
        ? { ...post, replies: [...post.replies, newReply] }
        : post
    );

    savePosts(updatedPosts);
    setSelectedPost({ ...selectedPost, replies: [...selectedPost.replies, newReply] });
    setReplyContent("");
  };

  const likePost = (postId: string) => {
    const updatedPosts = posts.map((post) =>
      post.id === postId ? { ...post, likes: post.likes + 1 } : post
    );
    savePosts(updatedPosts);
    if (selectedPost?.id === postId) {
      setSelectedPost({ ...selectedPost, likes: selectedPost.likes + 1 });
    }
  };

  const getTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);

    if (seconds < 60) return "just now";
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    return `${Math.floor(seconds / 86400)}d ago`;
  };

  const categories = ["Support", "Stress", "Anxiety", "Depression", "Resources", "Success Stories"];

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-3xl mb-2">Community Forum</h1>
        <p className="text-muted-foreground">
          Connect with others, share experiences, and find support
        </p>
      </motion.div>

      <AnimatePresence mode="wait">
        {!selectedPost ? (
          <motion.div
            key="list"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="space-y-6"
          >
            {/* Create Post Button */}
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Users className="size-5 text-purple-500" />
                <span className="text-lg font-semibold">{posts.length} Posts</span>
              </div>
              <Button onClick={() => setShowNewPost(!showNewPost)} className="gap-2">
                <Plus className="size-4" />
                New Post
              </Button>
            </div>

            {/* New Post Form */}
            <AnimatePresence>
              {showNewPost && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                >
                  <Card>
                    <CardHeader>
                      <CardTitle>Create a New Post</CardTitle>
                      <CardDescription>
                        Share your thoughts, ask questions, or offer support
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <Label>Title</Label>
                        <Input
                          placeholder="What's on your mind?"
                          value={newPostData.title}
                          onChange={(e) =>
                            setNewPostData({ ...newPostData, title: e.target.value })
                          }
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Category</Label>
                        <div className="flex gap-2 flex-wrap">
                          {categories.map((category) => (
                            <Button
                              key={category}
                              variant={newPostData.category === category ? "default" : "outline"}
                              size="sm"
                              onClick={() => setNewPostData({ ...newPostData, category })}
                            >
                              {category}
                            </Button>
                          ))}
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label>Content</Label>
                        <Textarea
                          placeholder="Share your thoughts..."
                          value={newPostData.content}
                          onChange={(e) =>
                            setNewPostData({ ...newPostData, content: e.target.value })
                          }
                          rows={4}
                        />
                      </div>
                      <div className="flex gap-2">
                        <Button onClick={createPost}>Post</Button>
                        <Button variant="outline" onClick={() => setShowNewPost(false)}>
                          Cancel
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Privacy Notice */}
            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="pt-6">
                <p className="text-sm text-blue-900">
                  <strong>Privacy Note:</strong> All posts are anonymous. Please don't share
                  personally identifiable information. This forum is for peer support, not
                  professional advice.
                </p>
              </CardContent>
            </Card>

            {/* Posts List */}
            <div className="space-y-4">
              {posts.map((post, index) => (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <Card
                    className="hover:shadow-md transition-shadow cursor-pointer"
                    onClick={() => setSelectedPost(post)}
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant="secondary">{post.category}</Badge>
                            <span className="text-xs text-muted-foreground flex items-center gap-1">
                              <Clock className="size-3" />
                              {getTimeAgo(post.createdAt)}
                            </span>
                          </div>
                          <CardTitle className="text-lg hover:text-purple-600 transition-colors">
                            {post.title}
                          </CardTitle>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
                        {post.content}
                      </p>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Heart className="size-4" />
                          {post.likes}
                        </span>
                        <span className="flex items-center gap-1">
                          <MessageCircle className="size-4" />
                          {post.replies.length} {post.replies.length === 1 ? "reply" : "replies"}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}

              {posts.length === 0 && (
                <Card>
                  <CardContent className="py-12 text-center">
                    <Users className="size-12 mx-auto mb-4 text-gray-300" />
                    <p className="text-muted-foreground">
                      No posts yet. Be the first to start a conversation!
                    </p>
                  </CardContent>
                </Card>
              )}
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="post"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSelectedPost(null)}
              className="mb-4"
            >
              ← Back to forum
            </Button>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="secondary">{selectedPost.category}</Badge>
                  <span className="text-xs text-muted-foreground">
                    Posted {getTimeAgo(selectedPost.createdAt)}
                  </span>
                </div>
                <CardTitle className="text-2xl">{selectedPost.title}</CardTitle>
                <CardDescription>by {selectedPost.userName}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <p className="text-base whitespace-pre-wrap">{selectedPost.content}</p>

                <div className="flex items-center gap-4 pt-4 border-t">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => likePost(selectedPost.id)}
                    className="gap-2"
                  >
                    <Heart className="size-4" />
                    {selectedPost.likes}
                  </Button>
                  <span className="text-sm text-muted-foreground">
                    {selectedPost.replies.length} {selectedPost.replies.length === 1 ? "reply" : "replies"}
                  </span>
                </div>

                {/* Replies */}
                <div className="space-y-4 pt-4 border-t">
                  <h3 className="font-semibold">Replies</h3>
                  {selectedPost.replies.map((reply, index) => (
                    <motion.div
                      key={reply.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="p-4 bg-gray-50 rounded-lg border"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold text-sm">{reply.userName}</span>
                        <span className="text-xs text-muted-foreground">
                          {getTimeAgo(reply.createdAt)}
                        </span>
                      </div>
                      <p className="text-sm whitespace-pre-wrap">{reply.content}</p>
                    </motion.div>
                  ))}

                  {selectedPost.replies.length === 0 && (
                    <p className="text-sm text-muted-foreground text-center py-4">
                      No replies yet. Be the first to respond!
                    </p>
                  )}
                </div>

                {/* Reply Form */}
                <div className="space-y-2 pt-4 border-t">
                  <Label>Add a Reply</Label>
                  <Textarea
                    placeholder="Share your thoughts..."
                    value={replyContent}
                    onChange={(e) => setReplyContent(e.target.value)}
                    rows={3}
                  />
                  <Button onClick={addReply} disabled={!replyContent.trim()} className="gap-2">
                    <Send className="size-4" />
                    Post Reply
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
