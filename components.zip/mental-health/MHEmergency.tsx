import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Phone, MessageSquare, Globe, AlertCircle, Heart, Shield } from "lucide-react";
import { motion } from "motion/react";

const emergencyContacts = [
  {
    name: "National Suicide Prevention Lifeline",
    number: "988",
    description: "24/7 crisis support for people in suicidal crisis or emotional distress",
    type: "Call",
    country: "USA",
  },
  {
    name: "Crisis Text Line",
    number: "Text 'HELLO' to 741741",
    description: "24/7 crisis support via text message",
    type: "Text",
    country: "USA",
  },
  {
    name: "SAMHSA National Helpline",
    number: "1-800-662-4357",
    description: "Treatment referral and information service for mental health and substance abuse",
    type: "Call",
    country: "USA",
  },
  {
    name: "Veterans Crisis Line",
    number: "988 (Press 1)",
    description: "24/7 confidential support for veterans and their families",
    type: "Call",
    country: "USA",
  },
  {
    name: "NAMI Helpline",
    number: "1-800-950-6264",
    description: "Information, referrals, and support for mental health concerns",
    type: "Call",
    country: "USA",
  },
  {
    name: "The Trevor Project (LGBTQ+)",
    number: "1-866-488-7386",
    description: "Crisis intervention and suicide prevention for LGBTQ+ youth",
    type: "Call",
    country: "USA",
  },
];

const internationalContacts = [
  { country: "Canada", number: "1-833-456-4566", name: "Talk Suicide Canada" },
  { country: "UK", number: "116 123", name: "Samaritans" },
  { country: "Australia", number: "13 11 14", name: "Lifeline" },
  { country: "India", number: "022-2754 6669", name: "AASRA" },
  { country: "International", number: "Visit findahelpline.com", name: "Find A Helpline" },
];

const warningSign = [
  "Talking about wanting to die or hurt oneself",
  "Looking for ways to end one's life",
  "Talking about feeling hopeless or having no purpose",
  "Talking about feeling trapped or in unbearable pain",
  "Increasing use of alcohol or drugs",
  "Withdrawing from friends and family",
  "Sleeping too much or too little",
  "Extreme mood swings",
];

export default function MHEmergency() {
  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="flex items-center gap-3 mb-2">
          <AlertCircle className="size-8 text-red-500" />
          <h1 className="text-3xl">Emergency & Crisis Support</h1>
        </div>
        <p className="text-muted-foreground">
          Immediate help is available. You are not alone.
        </p>
      </motion.div>

      {/* Immediate Action Card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.1 }}
      >
        <Card className="border-red-300 bg-red-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-900">
              <Shield className="size-6" />
              If You're in Immediate Danger
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-red-900 text-lg font-medium">
              If you or someone you know is in immediate danger, please:
            </p>
            <div className="grid md:grid-cols-2 gap-4">
              <Button size="lg" className="h-auto py-4 bg-red-600 hover:bg-red-700">
                <div className="flex flex-col items-center gap-2">
                  <Phone className="size-6" />
                  <span className="text-lg">Call 911</span>
                  <span className="text-xs opacity-90">Emergency Services</span>
                </div>
              </Button>
              <Button size="lg" className="h-auto py-4 bg-red-600 hover:bg-red-700">
                <div className="flex flex-col items-center gap-2">
                  <Phone className="size-6" />
                  <span className="text-lg">Call 988</span>
                  <span className="text-xs opacity-90">Suicide & Crisis Lifeline</span>
                </div>
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Crisis Hotlines */}
      <div className="grid md:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Phone className="size-5 text-blue-500" />
                24/7 Crisis Hotlines (USA)
              </CardTitle>
              <CardDescription>
                Free, confidential support available anytime
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {emergencyContacts.map((contact, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 + index * 0.05 }}
                  className="p-4 border rounded-lg hover:border-blue-300 hover:bg-blue-50/50 transition-all"
                >
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-semibold text-sm">{contact.name}</h3>
                    <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">
                      {contact.type}
                    </span>
                  </div>
                  <p className="text-lg font-bold text-blue-600 mb-2">{contact.number}</p>
                  <p className="text-sm text-muted-foreground">{contact.description}</p>
                </motion.div>
              ))}
            </CardContent>
          </Card>
        </motion.div>

        <div className="space-y-6">
          {/* International */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="size-5 text-green-500" />
                  International Helplines
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {internationalContacts.map((contact, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 + index * 0.05 }}
                    className="flex items-center justify-between p-3 border rounded-lg"
                  >
                    <div>
                      <div className="font-semibold text-sm">{contact.country}</div>
                      <div className="text-xs text-muted-foreground">{contact.name}</div>
                    </div>
                    <div className="text-sm font-mono font-bold text-green-600">
                      {contact.number}
                    </div>
                  </motion.div>
                ))}
              </CardContent>
            </Card>
          </motion.div>

          {/* Online Resources */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="size-5 text-purple-500" />
                  Online Support
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 border rounded-lg">
                  <div className="font-semibold text-sm mb-1">Crisis Text Line</div>
                  <p className="text-sm text-muted-foreground mb-2">
                    Text support available 24/7
                  </p>
                  <Button variant="outline" size="sm" className="w-full">
                    Text HELLO to 741741
                  </Button>
                </div>
                <div className="p-3 border rounded-lg">
                  <div className="font-semibold text-sm mb-1">BetterHelp</div>
                  <p className="text-sm text-muted-foreground mb-2">
                    Online therapy and counseling
                  </p>
                  <Button variant="outline" size="sm" className="w-full">
                    Visit Website
                  </Button>
                </div>
                <div className="p-3 border rounded-lg">
                  <div className="font-semibold text-sm mb-1">7 Cups</div>
                  <p className="text-sm text-muted-foreground mb-2">
                    Free emotional support and counseling
                  </p>
                  <Button variant="outline" size="sm" className="w-full">
                    Chat Now
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>

      {/* Warning Signs */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Heart className="size-5 text-pink-500" />
              Warning Signs of a Crisis
            </CardTitle>
            <CardDescription>
              If you or someone you know shows these signs, reach out for help
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-3">
              {warningSign.map((sign, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.6 + index * 0.05 }}
                  className="flex items-start gap-2 p-3 bg-orange-50 border border-orange-200 rounded-lg"
                >
                  <AlertCircle className="size-4 text-orange-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm text-orange-900">{sign}</span>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Supportive Message */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
      >
        <Card className="bg-gradient-to-r from-blue-500 to-purple-500 text-white border-none">
          <CardContent className="py-8 text-center">
            <Heart className="size-12 mx-auto mb-4" fill="currentColor" />
            <h2 className="text-2xl font-bold mb-2">You Matter</h2>
            <p className="text-lg opacity-90 max-w-2xl mx-auto">
              Your life has value. You are important. Help is available, and people care about you.
              Reaching out is a sign of strength, not weakness.
            </p>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
