import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Textarea } from "../ui/textarea";
import { Label } from "../ui/label";
import { Smile, Meh, Frown, TrendingUp, Calendar, Heart } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { motion } from "motion/react";
import { MoodEntry } from "../../types/mental-health";

const moodOptions = [
  { value: 5, label: "Excellent", emoji: "😄", color: "bg-green-500" },
  { value: 4, label: "Good", emoji: "🙂", color: "bg-blue-500" },
  { value: 3, label: "Okay", emoji: "😐", color: "bg-yellow-500" },
  { value: 2, label: "Not Great", emoji: "😔", color: "bg-orange-500" },
  { value: 1, label: "Poor", emoji: "😢", color: "bg-red-500" },
];

const affirmations = [
  "You are stronger than you think.",
  "It's okay to take things one day at a time.",
  "Your feelings are valid and important.",
  "You deserve kindness and compassion.",
  "Every small step forward is progress.",
  "You are doing your best, and that's enough.",
  "It's okay to ask for help when you need it.",
  "You are worthy of love and happiness.",
];

export default function MHDashboard() {
  const [user, setUser] = useState<any>(null);
  const [selectedMood, setSelectedMood] = useState<number | null>(null);
  const [moodNote, setMoodNote] = useState("");
  const [moodHistory, setMoodHistory] = useState<MoodEntry[]>([]);
  const [dailyAffirmation, setDailyAffirmation] = useState("");

  useEffect(() => {
    const currentUser = JSON.parse(localStorage.getItem("mh_current_user") || "{}");
    setUser(currentUser);

    // Load mood history
    const history = JSON.parse(localStorage.getItem(`mh_moods_${currentUser.id}`) || "[]");
    setMoodHistory(history);

    // Set daily affirmation
    const today = new Date().toDateString();
    const savedAffirmation = localStorage.getItem("daily_affirmation");
    const savedDate = localStorage.getItem("affirmation_date");

    if (savedDate !== today) {
      const randomAffirmation = affirmations[Math.floor(Math.random() * affirmations.length)];
      setDailyAffirmation(randomAffirmation);
      localStorage.setItem("daily_affirmation", randomAffirmation);
      localStorage.setItem("affirmation_date", today);
    } else {
      setDailyAffirmation(savedAffirmation || affirmations[0]);
    }
  }, []);

  const saveMood = () => {
    if (selectedMood === null) return;

    const newEntry: MoodEntry = {
      id: Date.now().toString(),
      userId: user.id,
      date: new Date().toISOString(),
      mood: selectedMood,
      note: moodNote,
    };

    const updatedHistory = [...moodHistory, newEntry];
    setMoodHistory(updatedHistory);
    localStorage.setItem(`mh_moods_${user.id}`, JSON.stringify(updatedHistory));

    setSelectedMood(null);
    setMoodNote("");
  };

  // Prepare chart data (last 7 days)
  const chartData = moodHistory.slice(-7).map((entry) => ({
    date: new Date(entry.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    mood: entry.mood,
  }));

  const averageMood = moodHistory.length > 0
    ? (moodHistory.reduce((sum, entry) => sum + entry.mood, 0) / moodHistory.length).toFixed(1)
    : 0;

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-3xl mb-2">Welcome back, {user?.name}!</h1>
        <p className="text-muted-foreground">How are you feeling today?</p>
      </motion.div>

      {/* Daily Affirmation */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.1 }}
      >
        <Card className="bg-gradient-to-r from-purple-500 to-pink-500 text-white border-none">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Heart className="size-5" fill="currentColor" />
              Daily Affirmation
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-lg italic">"{dailyAffirmation}"</p>
          </CardContent>
        </Card>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Mood Tracker */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Track Your Mood</CardTitle>
              <CardDescription>How are you feeling right now?</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-5 gap-2">
                {moodOptions.map((option) => (
                  <motion.button
                    key={option.value}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setSelectedMood(option.value)}
                    className={`p-3 rounded-lg border-2 transition-all ${
                      selectedMood === option.value
                        ? "border-purple-500 bg-purple-50"
                        : "border-gray-200 hover:border-gray-300"
                    }`}
                  >
                    <div className="text-3xl mb-1">{option.emoji}</div>
                    <div className="text-xs text-gray-600">{option.label}</div>
                  </motion.button>
                ))}
              </div>

              <div className="space-y-2">
                <Label>Add a note (optional)</Label>
                <Textarea
                  placeholder="What's on your mind?"
                  value={moodNote}
                  onChange={(e) => setMoodNote(e.target.value)}
                  rows={3}
                />
              </div>

              <Button
                onClick={saveMood}
                disabled={selectedMood === null}
                className="w-full"
              >
                Save Mood
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="space-y-4"
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="size-5" />
                Your Statistics
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-3xl font-bold text-blue-600">{moodHistory.length}</div>
                  <div className="text-sm text-gray-600">Entries</div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-3xl font-bold text-green-600">{averageMood}</div>
                  <div className="text-sm text-gray-600">Avg Mood</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="size-5" />
                Recent Entries
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {moodHistory.slice(-5).reverse().map((entry) => {
                  const mood = moodOptions.find(m => m.value === entry.mood);
                  return (
                    <div key={entry.id} className="flex items-center gap-3 p-2 rounded-lg bg-gray-50">
                      <span className="text-2xl">{mood?.emoji}</span>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium">{mood?.label}</div>
                        <div className="text-xs text-gray-500">
                          {new Date(entry.date).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                  );
                })}
                {moodHistory.length === 0 && (
                  <p className="text-sm text-gray-500 text-center py-4">
                    No entries yet. Start tracking your mood!
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Mood Chart */}
      {chartData.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Mood Trends (Last 7 Entries)</CardTitle>
              <CardDescription>Track your emotional patterns over time</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis domain={[1, 5]} ticks={[1, 2, 3, 4, 5]} />
                  <Tooltip />
                  <Line
                    type="monotone"
                    dataKey="mood"
                    stroke="#8b5cf6"
                    strokeWidth={3}
                    dot={{ fill: "#8b5cf6", r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  );
}
